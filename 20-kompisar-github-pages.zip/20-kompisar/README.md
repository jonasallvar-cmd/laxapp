# 20 kompisar

Mattespel för att öva addition och subtraktion till 20. Fyra teman (djur, rymd, dinosaurier, fotboll), stjärnor och figurer att samla.

## Publicera på GitHub Pages
1. Skapa ett nytt repo på github.com (t.ex. `20-kompisar`), publikt.
2. Ladda upp ALLA filer i den här mappen (index.html, sw.js, manifest.webmanifest och mappen icons).
3. Gå till Settings > Pages. Välj Source: "Deploy from a branch", Branch: `main`, mapp `/ (root)`. Spara.
4. Efter någon minut finns appen på `https://DITTNAMN.github.io/20-kompisar/`.

## Installera på iPad
Öppna adressen i Safari > Dela-knappen > "Lägg till på hemskärmen". Efter första öppningen fungerar appen utan nätverk.

## Uppdatera
Ändra filerna i repot. Höj versionen `V` i sw.js (t.ex. `kompisar-v2`) så att iPaden hämtar nya filer.
